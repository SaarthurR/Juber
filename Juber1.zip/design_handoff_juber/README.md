# Handoff: Juber — JCNC Carpool redesign

## Overview
Juber is a Moober-style carpool board for the **Jain Center of Northern California (JCNC)** community —
members offer and find rides to the temple in Milpitas and to JCNC events (Paryushan, Das Lakshana, etc.).
Tagline: *"Ahimsa on the road."*

This bundle contains a redesigned visual system and the core app screens: a fresh home/rides board,
request-a-ride, ride requests, trip details (with a contact modal), profile, edit profile, and an
events/Paryushan board — plus a logo and a notifications system in the top bar.

## About the design files
`Juber.dc.html` is a **design reference created in HTML** — a prototype showing the intended look,
layout, and behavior. It is **not production code to copy directly.** Your task in Claude Code is to
**recreate these designs in the existing JCNC Carpool codebase** (Next.js App Router + Tailwind v4 +
Supabase) using its established patterns, components, and data model — not to drop the HTML in.

> Open `Juber.dc.html` in a browser to see everything. It is laid out as one long exploration page:
> Section 01 logos, 02 palettes, 03 the three home directions, 04 the six app screens. Each screen
> carries a `data-screen-label` attribute so you can find it quickly.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, and interactions are all specified below
and present in the HTML. Recreate the UI faithfully using your Tailwind theme + React components.

## Which direction to build
Three home directions are shown. **Build "JCNC Heritage" (the brightened brown system)** — it is the
direction the design converged on, and all six app screens are already themed in it. The other two
(Indigo Calm, Marigold Warm) are kept only for reference; swapping the accent token is a one-line change
if you ever want them.

The Heritage system keeps the *clarity* of the indigo direction (clean white cards, generous spacing,
clear hierarchy) and puts the warm brand brown **on the buttons and active states** the way the indigo
direction used purple.

---

## Design tokens

### Colors — JCNC Heritage (primary)
| Token | Hex | Use |
|---|---|---|
| `--brand` (primary) | `#A65329` | Buttons, active nav link, active tab + underline, links, route end-dot, focus border |
| `--brand-deep` | `#8A4420` | Chip text, gradient dark stop, pressed/hover |
| `--brand-bright` | `#C9712F` | Gradient light stop, avatar gradient |
| `--gold` | `#C99A2E` | Route line, small highlights |
| `--gold-light` | `#E8C887` | Eyebrow text on brown hero band |
| `--tint` | `#F6E9DA` | Soft fills: chip bg, nav avatar bg, icon tiles |
| `--sand` | `#F3E7D8` | Heritage chip bg (e.g. "2 seats left") |
| `--sand-text` | `#8A5A2B` | Text on sand chips |
| `--cream` | `#FBF7F0` | Page background (home), `#FBF6EE` subtle rows |
| `--card` | `#FFFFFF` | Cards, nav bar, screen bodies |
| `--ink` | `#1C1917` | Primary text + the dark trip-details band; warm alt `#2A1A0F` |
| `--muted` | `#78716C` / `#8A7256` | Secondary text |
| `--muted-warm` | `#A8927A` / `#B0A08D` | Tertiary / timestamps |
| `--border` | `#EFE4D3` | Card + input borders (warm); neutral alt `#E2DDD5` |
| `--border-page` | `#E7DDCD` | Outer card border on cream |
| Danger dot | `#C2410C` / `#EF4444` | Notification unread badge |

Status / per-person avatar accents (kept varied for life — leave as-is): green `#DCFCE7`/`#15803D`,
blue `#DBEAFE`/`#1D4ED8`, red `#FEE2E2`/`#B91C1C`, amber `#FEF3C7`/`#B45309`, violet `#EDE4F5`/`#6D28D9`.

### Alternate accents (one-token swap)
- Indigo Calm: `#4F46E5` primary, `#4338CA` deep, `#6366F1` bright, `#EEF2FF` tint
- Marigold Warm: `#E8820C` primary, `#B45309` deep, `#FFF3E0` tint, `#F3E8D6` chip

### Typography
- **Family:** `Plus Jakarta Sans` (Google Fonts), weights 400/500/600/700/800. (Your repo currently uses
  Geist via `--font-sans`; either swap to Plus Jakarta Sans or keep Geist — the system tolerates either.
  If keeping Geist, the look holds; Plus Jakarta is what the mock uses.)
- **Scale:** page H1 46px/800 · screen titles 28–34px/800 (letter-spacing −0.02em) · section labels
  14–16px/700–800 · body 15–16px/400–600 · field labels 11–13px/700–800 UPPERCASE, letter-spacing
  0.1–0.14em · meta/timestamps 12–13px.
- Headings use `letter-spacing:-0.02em` and `text-wrap: pretty` where multi-line.

### Radius & shadow
- Radius: cards 16–20px · buttons 11–13px · inputs 12px · icon tiles 10–13px · chips/pills/avatars 999px.
- Card float shadow: `0 24px 50px -28px rgba(28,25,23,0.22)` (warm: `rgba(92,59,46,0.35)`).
- Dropdown shadow: `0 24px 50px -16px rgba(92,59,46,0.30)`.
- Buttons: solid `--brand` fill, white text, 700 weight; secondary = 1.5px `--brand` outline, `--brand` text.

### Spacing
8px base. Screen body padding ~34–44px desktop. Card padding 20–24px. Gaps: card stacks 16px,
form field groups 16–32px, nav items 22–26px.

---

## Screens / Views

All screens share a **top nav bar** (white, `--border` bottom): left = temple logo mark + "Juber"
wordmark in `--brand`; right = `Rides / Events / About` links (active link in `--brand`, weight 700),
a **notifications bell**, then the user avatar (`--tint` bg, `--brand` initials).

### Top bar — Notifications (new)
- Bell icon in a 38px `--tint` circle with a small unread dot (`#C2410C`, white ring) top-right.
- Click toggles a 340px dropdown anchored under the bell: header "Notifications" + "Mark all read";
  rows = avatar/icon chip + text + timestamp; unread rows have a faint tint bg and a `--gold` dot;
  footer "View all notifications". See it live on Home (Direction A and Direction C bells are wired).
- Notification copy used: seat-confirmed, new ride request, driver messaged you, Paryushan filling up.
- **State:** `openNotif: string | null` (which bell is open), toggled per bell; click-out closes.
  In React: local state or a small popover; route the live data from your notifications table.

### 1. Home / Rides board (`data-screen-label="Home C"`)
- **Purpose:** browse carpools to JCNC, search by from/to/date, jump to post or request.
- **Layout:** nav → brown **hero band** (`--brand` bg, faint temple silhouette SVG bottom-right,
  gold eyebrow "AHIMSA ON THE ROAD", headline, subcopy) → segmented toggle `Carpools | Ride requests`
  + "Post a ride" button → white **search card** (FROM / swap icon / TO / DATE) → vertical list of
  **ride cards** → co-brand footer.
- **Ride card:** white, `--border`, 4px `--gold` left accent, radius 14px. Top row: avatar + name +
  neighborhood, right = `$8` in `--brand` + "gas". Middle: origin · route line (start = hollow
  `--brand` ring, line = `--gold`, end = solid `--brand` dot) · "JCNC". Bottom: date/time (12px 700) +
  seat chip (`--sand` bg, `--sand-text`).
- **Co-brand footer:** "An initiative for the [JCNC logo] community · jcnc.org" — uses
  `assets/jcnc-logo.png` (449×66 transparent PNG) and links to https://jcnc.org/.

### 2. Request a ride (`data-screen-label="Request a ride"`)
- Single-column form (max ~760px): title → "Where are you heading?" two big toggle cards
  (To JCNC selected = `--brand` border + `--tint` fill) → Pick-up neighborhood select → Date range
  (earliest / latest) → Seats stepper (− 1 +) → Max gas contribution `$` field → Notes textarea →
  full-width **"Post ride request"** button (`--brand`).
- Field label pattern: 16px/700 title + 13px `--muted` helper above each input.

### 3. Ride requests (`data-screen-label="Ride requests"`)
- Back arrow + "Ride requests" title + "3 open" chip; "Post a ride" button right.
- Responsive grid (`minmax(330px,1fr)`) of **request cards:** avatar + name + "needs a ride" + seat
  chip; "From → To" route; flexible dates + max $ + a quoted note; secondary **"Offer a ride"**
  outline button (`--brand` outline/text).

### 4. Trip details + Contact modal (`data-screen-label="Trip details"`)
- Title row: back arrow + "Trip details" + "San Jose → JCNC, Milpitas" subtitle; right = `$8` gas +
  share icon.
- **Dark band** (`#1C1917`, white text): date/time + a pickup→dropoff timeline (white dots, neutral
  line).
- Body: DRIVER row (avatar + name + "she/her · drives a silver Camry") with a **"Contact"** link
  (phone icon, `--brand`) → TRUNK SPACE segmented (Compact / **Standard** selected / Spacious) →
  NOTE card (`#F7F5F2`) → GOING 2/4 with avatar stack (+ dashed empty slots) → full-width
  **"Reserve a seat"** button.
- **Contact modal:** click "Contact" → centered modal over a `rgba(28,25,23,0.55)` scrim.
  Title "Contact Priya" + ✕; rows for Email / Phone (marked **preferred**, `--brand`) / Instagram, each
  an icon tile + label + value. Click scrim or ✕ to close.
  **State:** `contactOpen: boolean`.

### 5. Profile (`data-screen-label="Profile"`)
- Two columns. **Left:** large gradient avatar (`135deg, --brand-bright → --brand-deep`), name,
  pronouns, neighborhood; a **Contact card** (`#F7F5F2`) with Email / Phone (preferred) / Instagram;
  an **"Edit profile"** outline button.
- **Right:** tabs `All rides | Rides posted | Rides joined | Ride requests` (active = `--brand`
  underline); UPCOMING section (ride card with a green "Confirmed" chip) and PAST RIDES (dimmed card).

### 6. Edit profile (`data-screen-label="Edit profile"`)
- Form column (max ~560px) + avatar column. Sections: **Personal information** (First name, Last
  initial, Pronouns, Neighborhood) and **Contact** (Phone — recommended, Instagram — optional, Car
  make & model, Preferred contact method select). Full-width **"Save changes"** button.
- Avatar column: 120px gradient avatar with a camera badge overlay + "Update photo / JPG or PNG, up to 4MB".

### 7. Events / Paryushan board (`data-screen-label="Events"`)
- Title + subcopy → **featured card** (`120deg, --brand-deep → --brand-bright` gradient, soft circle
  decorations): "FEATURED · HIGH DEMAND" badge, "Paryushan Parva", dates/venue, three stats
  (rides offered / seats open / people requesting), white "View rides" button.
- Below: grid of **event cards** (icon tile + ride count chip + event name + date + footer
  "N seats open / View rides →"). Events shown: Das Lakshana, Mahavir Janma Kalyanak, Diwali &
  Mahavir Nirvana.

---

## Logo
Six concepts are in Section 01 of the HTML. **Recommended: the "Temple" mark** (heritage brown),
which echoes the JCNC building logo — an inline SVG (see the Home C nav for the production-size mark).
A monochrome `--brand` temple icon + "Juber" wordmark (Plus Jakarta Sans 800, −0.03em). Keep the mark
at 26–30px in the nav. The JCNC institutional logo (`assets/jcnc-logo.png`) is used only as a co-brand
credit in the footer, not as the app logo.

## Interactions & behavior
- **Notifications:** bell toggles a popover; unread dot when unread > 0; "Mark all read" clears dots.
- **Contact modal:** open from Trip details "Contact"; close on scrim/✕/Esc.
- **Toggles/tabs:** segmented controls and profile tabs switch active styling (`--brand`).
- **Hover:** buttons darken to `--brand-deep`; cards may lift shadow slightly. (Define in Tailwind.)
- **Responsive:** every screen reflows to a single column on mobile — search row, two-column
  profile/edit, and card grids all `flex-wrap` / collapse. Keep tap targets ≥ 44px.

## State management
- `contactOpen: boolean` — trip details contact modal.
- `openNotif: string | null` — which notifications popover is open.
- Live data from Supabase: rides, ride_requests, places, profiles, and a notifications source feeding
  the bell. Map the mock's static content (Priya S., Amit J., JCNC Milpitas, $8 gas, Sep 6) to your
  real `rides` / `profiles` rows.

## Assets
- `assets/jcnc-logo.png` — JCNC institutional wordmark, 449×66 transparent PNG (co-brand footer only).
- All other marks/icons are inline SVG in `Juber.dc.html` (temple logo, bell, route dots, field icons,
  social icons). Copy the SVG paths into your icon components or swap for your existing icon set.
- Font: Plus Jakarta Sans via Google Fonts.

## Files
- `Juber.dc.html` — the full design reference (logos, palettes, 3 home directions, 6 app screens,
  working notifications + contact modal).
- `assets/jcnc-logo.png` — co-brand logo.

## Suggested Claude Code prompt
> "Implement the Juber redesign in this Next.js + Supabase app using the spec in
> `design_handoff_juber/README.md`. Build the **JCNC Heritage** theme: add the color tokens to my
> Tailwind theme in `globals.css`, then rebuild the home rides board, request-a-ride, ride requests,
> trip details (with contact modal), profile, edit profile, and events screens to match. Add a
> notifications bell + popover to the top nav. Keep my existing Supabase data layer and routes; wire
> the mock content to real rows. Reference `Juber.dc.html` for exact layout, colors, and copy."
